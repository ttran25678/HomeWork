package cybersoft.java12.oop.quanlynhansu.main;

import cybersoft.java12.oop.quanlynhansu.view.QuanLyNhanSuConsole;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuanLyNhanSuConsole quanLyNhanSuConsole = new QuanLyNhanSuConsole();

		quanLyNhanSuConsole.start();
	}

}
