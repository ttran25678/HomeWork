package javaCore22Exercises;

public class Exercise1AmericaFlag {

	public static void main(String[] args) {
		// TODO America flag
		System.out.println("* * * * * * =================================");
		System.out.println(" * * * * *  =================================");
		System.out.println("* * * * * * =================================");
		System.out.println(" * * * * *  =================================");
		System.out.println("* * * * * * =================================");
		System.out.println(" * * * * *  =================================");
		System.out.println("* * * * * * =================================");
		System.out.println(" * * * * *  =================================");
		System.out.println("* * * * * * =================================");
		System.out.println("=============================================");
		System.out.println("=============================================");
		System.out.println("=============================================");
		System.out.println("=============================================");
		System.out.println("=============================================");
		System.out.println("=============================================");
		
		
		
	}

}
