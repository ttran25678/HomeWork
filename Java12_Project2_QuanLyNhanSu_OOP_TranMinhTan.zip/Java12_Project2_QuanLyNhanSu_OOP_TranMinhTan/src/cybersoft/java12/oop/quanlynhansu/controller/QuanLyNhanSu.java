package cybersoft.java12.oop.quanlynhansu.controller;

import java.util.LinkedList;
import java.util.List;

import cybersoft.java12.oop.quanlynhansu.GiamDoc;
import cybersoft.java12.oop.quanlynhansu.NhanSu;
import cybersoft.java12.oop.quanlynhansu.NhanVien;
import cybersoft.java12.oop.quanlynhansu.TruongPhong;

public class QuanLyNhanSu {
	List<NhanSu> dsNhanSu = new LinkedList<NhanSu>();
	int maNhanSu = 3;
	// int maSo, String hoTen, String soDienThoai, float luongMotNgay

	// khởi tạo mặc định. cty ban đầu phải có 1 giám đốc, 1 trưởng phòng và
	// 1 nhân viên thuộc trưởng phòng đó
	public QuanLyNhanSu() {
		super();
		NhanVien nv0 = new NhanVien(1, "Anh Nhân viên", "0987654321", 30.0f, 100.0f, "2");
		dsNhanSu.add(nv0);
		TruongPhong tp0 = new TruongPhong(2, "Anh Trưởng Phòng", "0987654321", 30.0f, 200.0f, 1);
		TruongPhong tp = tp0;
		dsNhanSu.add(tp);
		GiamDoc gd0 = new GiamDoc(3, "Anh Giám đốc", "0987654321", 30.0f, 300.0f, 40.0f);
		dsNhanSu.add(gd0);
	}

	public void xuatDSNhanSu() {
		for (NhanSu item : dsNhanSu) {
			item.xuatThongTin();
		}
	}

	public int xuatSoLuongDSNhanSu() {
		return dsNhanSu.size();
	}

	public int xuatSLNhanVien() {
		int index = 0;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof NhanVien) {
				index++;
			}
		}

		return index;
	}

	public int xuatSLTruongPhong() {
		int index = 0;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof TruongPhong) {
				index++;
			}
		}

		return index;
	}

	public int xuatSLGiamDoc() {
		int index = 0;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof GiamDoc) {
				index++;
			}
		}

		return index;
	}

	public boolean timMaTonTai(int ma) {
		for (NhanSu item : dsNhanSu) {
			if (ma == item.getMaSo())
				return true;
		}
		return false;
	}

	public boolean them(NhanSu nhanSu) {
		if (nhanSu instanceof NhanVien) {
			NhanVien nvMoi = new NhanVien();
			nvMoi = nvMoi.themNhanVien();
			maNhanSu++;
			nvMoi.setMaSo(maNhanSu);
			dsNhanSu.add(nvMoi);
		}

		if (nhanSu instanceof TruongPhong) {
			TruongPhong tpMoi = new TruongPhong();
			tpMoi = tpMoi.themTruongPhong();
			maNhanSu++;
			tpMoi.setMaSo(maNhanSu);
			dsNhanSu.add(tpMoi);
		}

		if (nhanSu instanceof GiamDoc) {
			GiamDoc gdMoi = new GiamDoc();
			gdMoi = gdMoi.themGiamDoc();
			maNhanSu++;
			gdMoi.setMaSo(maNhanSu);
			dsNhanSu.add(gdMoi);
		}

		return true;
	}

	public boolean xoa(int maSo) {
		if (this.xuatSLTruongPhong() == 0) {
			return false;
		}
		if (this.xuatSLNhanVien() == 0) {
			return false;
		}
		if (this.xuatSLGiamDoc() == 0) {
			return false;
		}
		for (NhanSu item : dsNhanSu) {
			if (maSo == item.getMaSo()) {
				if (item instanceof GiamDoc) {
					dsNhanSu.remove(item);
					return true;
				}
				if (item instanceof NhanVien) {
					for (NhanSu subItem : dsNhanSu) { // duyệt tìm
						if (subItem instanceof TruongPhong) { // ...trưởng phòng
							// ...có mã TP = truongPhong(của NV)
							if (((NhanVien) item).getTruongPhong().equals(String.valueOf(subItem.getMaSo()))) {
								// sl nhân viên != 0. tức là có cấp dưới
								if (((TruongPhong) subItem).getSoNhanVien() != 0) {
									int val = ((TruongPhong) subItem).getSoNhanVien();
									((TruongPhong) subItem).setSoNhanVien(--val); // giảm số lượng NV để xóa NV
									dsNhanSu.remove(item);
									return true;
								}
							}
						}
					}
				}
				if (item instanceof TruongPhong) {
					if (((TruongPhong) item).getSoNhanVien() == 0) {
						dsNhanSu.remove(item);
						return true;
					} else {
						for (NhanSu subItem : dsNhanSu) {
							if (subItem instanceof NhanVien) {
								if (((NhanVien) subItem).getTruongPhong().equals(String.valueOf(item.getMaSo()))) {
									((NhanVien) subItem).setTruongPhong(null);// xóa mã trưởng phòng trong NV thuộc
																				// phòng đó
								}
							}
						}
						dsNhanSu.remove(item);
						return true;
					}
				}
			}
		}

		return false; // tìm tới đây mà k thấy mã nào trùng với mã nhập vào thì zề nhà thôi.
	}

	public boolean themNVVaoTruongPhong() {
		NhanVien nv = new NhanVien();
		int maNVPB = nv.nhapMaNVCanPhanBo();
		int maTP = nv.nhapMaTPPhanBo();
		if (!timMaTonTai(maTP)) { // mã trưởng phòng phải tồn tại và nó phải có kiểu là trưởng phòng
			return false;
		} else {
			for (NhanSu item : dsNhanSu) {
				if (maTP == item.getMaSo()) {
					if (!(item instanceof TruongPhong)) {
						return false;
					}
				}
			}
		}
		for (NhanSu item : dsNhanSu) {
			if (item.getMaSo() == maNVPB) {
				if (item instanceof TruongPhong || item instanceof GiamDoc) {
					return false;
				} else {
					// nếu NV đó chuyển phòng thì TP củ của NV đó phải -- số lượng VN
					if (((NhanVien) item).getTruongPhong() == null || ((NhanVien) item).getTruongPhong() == "") {
						for (NhanSu subItem : dsNhanSu) {
							if (maTP == subItem.getMaSo()) {
								if (subItem instanceof GiamDoc || subItem instanceof NhanVien) {
									return false;
								} else {
									// nhân viên thêm vào phòng nên có mã trưởng phòng
									((NhanVien) item).setTruongPhong(String.valueOf(subItem.getMaSo()));
									((TruongPhong) subItem).themSoLuongNV(); // trưởng phòng có thêm nhân viên
									return true;
								}
							}
						}
						return false;
					} else {
						for (NhanSu lst : dsNhanSu) {
							if (Integer.parseInt(((NhanVien) item).getTruongPhong()) == lst.getMaSo()) {
								((TruongPhong) lst).setSoNhanVien(((TruongPhong) lst).getSoNhanVien() - 1);
							}
						}
						for (NhanSu subItem : dsNhanSu) {
							if (maTP == subItem.getMaSo()) {
								// nhân viên thêm vào phòng nên có mã trưởng phòng ((NhanVien)
								((NhanVien) item).setTruongPhong(String.valueOf(subItem.getMaSo()));
								((TruongPhong) subItem).themSoLuongNV();// trưởng phòng có thêm nhân viên
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}

	public double tongLuong() {
		double luongTongCty = 0;
		if (dsNhanSu.size() == 0) {
			return luongTongCty;
		} else {
			for (NhanSu item : dsNhanSu) {
				luongTongCty += item.tinhLuong();
			}
		}
		return luongTongCty;
	}

	public void timNVLuongCaoNhat() {
		float max = -1;
		int index = -1;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof NhanVien) {
				if (item.tinhLuong() > max) {
					max = item.tinhLuong();
					index = item.getMaSo();
				}
			}
		}
		for (NhanSu item : dsNhanSu) {
			if (index == item.getMaSo()) {
				item.xuatThongTin();
			}
		}
	}

	public void timTPCoNhieuNV() {
		int max = -1;
		int index = -1;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof TruongPhong) {
				if (((TruongPhong) item).getSoNhanVien() > max) {
					max = ((TruongPhong) item).getSoNhanVien();
					index = item.getMaSo();
				}
			}
		}

		for (NhanSu item : dsNhanSu) {
			if (index == item.getMaSo()) {
				item.xuatThongTin();
			}
		}
	}

	public void timGDCoNhieuCoPhanNhat() {
		float max = -1;
		int index = -1;
		for (NhanSu item : dsNhanSu) {
			if (item instanceof GiamDoc) {
				if (((GiamDoc) item).getCoPhan() > max) {
					max = ((GiamDoc) item).getCoPhan();
					index = item.getMaSo();
				}
			}
		}
		
		for (NhanSu item : dsNhanSu) {
			if (index == item.getMaSo()) {
				item.xuatThongTin();
			}
		}
	}
	
	public void thuNhapTungGiamDoc() {
		for(NhanSu item:dsNhanSu) {
			if(item instanceof GiamDoc) {
				item.xuatThongTin();
				((GiamDoc)item).xuatThuNhapGiamDoc();
			}
		}
	}
	
	
	

}
