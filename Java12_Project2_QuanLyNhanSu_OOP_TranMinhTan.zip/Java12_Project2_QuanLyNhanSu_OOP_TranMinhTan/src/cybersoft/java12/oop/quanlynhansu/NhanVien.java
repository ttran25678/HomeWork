package cybersoft.java12.oop.quanlynhansu;

public class NhanVien extends NhanSu{
	private String truongPhong;

	public String getTruongPhong() {
		return truongPhong;
	}

	public void setTruongPhong(String truongPhong) {
		this.truongPhong = truongPhong;
	}
	
	public NhanVien() {
		super();
	}
	
	public NhanVien(int maSo, String hoTen, String soDienThoai,float soNgayLam, float luongMotNgay) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
	}

	public NhanVien(int maSo, String hoTen, String soDienThoai,float soNgayLam, float luongMotNgay, String truongPhong) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		this.truongPhong = truongPhong;
	}

	@Override
	public void xuatThongTin() {
		// TODO Auto-generated method stub
		super.xuatThongTin();
		System.out.printf("Mã Trưởng phòng: %s\n", getTruongPhong());
	}
		
	public NhanVien themNhanVien() {
		NhanVien nvMoi = new NhanVien();
		nvMoi.setHoTen(nhapString("", sc, "Nhập họ tên: "));
		do {
			nvMoi.setSoDienThoai(inputValues("", sc, "Nhập số điện thoại: "));
			if(nvMoi.getSoDienThoai().length() > 10 || nvMoi.getSoDienThoai().length() < 10 || !(nvMoi.getSoDienThoai().startsWith("0"))) {
				System.out.println("SAI. Số điện thoại đúng 10 số và bắt đầu bằng số 0 !");
			}
		}while(nvMoi.getSoDienThoai().length() > 10 || nvMoi.getSoDienThoai().length() < 10 || !(nvMoi.getSoDienThoai().startsWith("0")));
		nvMoi.setSoNgayLam(Float.parseFloat(inputValues("", sc, "Nhập số ngày làm: ")));
		nvMoi.setLuongMotNgay(Float.parseFloat(inputValues("", sc, "Nhập tiền lương 1 ngày: ")));
		return nvMoi;
	}
	
	public int nhapMaNVCanPhanBo() {
		NhanSu ns = new NhanSu();
		return Integer.parseInt(ns.inputValues("", sc, "Nhập mã Nhân Viên cần phân bổ: ")); // trong hàm nhập gọi hàm check validation trả về string 	
	}
	
	public int nhapMaTPPhanBo() {
		NhanSu ns = new NhanSu();
		return Integer.parseInt(ns.inputValues("", sc, "Nhập mã Trưởng phòng phân bổ: ")); // trong hàm nhập gọi hàm check validation trả về string 	
	}
	
	@Override
	public float tinhLuong() {
		// TODO Auto-generated method stub
		return super.tinhLuong();
	}
	
	
	
}
