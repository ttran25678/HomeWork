package cybersoft.java12.oop.quanlynhansu;

import java.util.Scanner;

public class NhanSu {
	private int maSo;
	private String hoTen;
	private String soDienThoai;
	private float soNgayLam;
	private float luongMotNgay;

	Scanner sc = new Scanner(System.in);

	public int getMaSo() {
		return maSo;
	}

	public void setMaSo(int maSo) {
		this.maSo = maSo;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	public float getSoNgayLam() {
		return soNgayLam;
	}

	public void setSoNgayLam(float soNgayLam) {
		this.soNgayLam = soNgayLam;
	}

	public float getLuongMotNgay() {
		return luongMotNgay;
	}

	public void setLuongMotNgay(float luongMotNgay) {
		this.luongMotNgay = luongMotNgay;
	}

	public NhanSu() {
		super();
	}

	public NhanSu(int maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		super();
		this.maSo = maSo;
		this.hoTen = hoTen;
		this.soDienThoai = soDienThoai;
		this.soNgayLam = soNgayLam;
		this.luongMotNgay = luongMotNgay;
	}

	public float tinhLuong() {
		return soNgayLam * luongMotNgay;
	}

	public boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?");
	}

	public String nhapString(String str, Scanner sc, String mess) {
		while (true) {
			System.out.printf(mess);
			str = sc.nextLine();
			if(str == null || str.isEmpty()) {
				System.out.println("SAI. Không được để trống !");
			}else {
				return str;
			}
		}
	}
	
	public String inputValues(String str, Scanner sc, String mess) {
		while (true) {
			System.out.printf(mess);
			str = sc.nextLine();
			if(str == null || str.isEmpty()) {
				System.out.println("SAI. Không được để trống !");
			}else if (isNumeric(str)) {
				break;
			} else {
				System.out.println("NHAP SAI!");
			}
		}
		return str;
	}

//	public NhanSu themNhanSu() {
//		NhanSu nsMoi = new NhanSu();
//		nsMoi.setHoTen(nhapString("", sc, "Nhập họ tên: "));
//		do {
//			nsMoi.setSoDienThoai(inputValues("", sc, "Nhập số điện thoại: "));
//			if(nsMoi.getSoDienThoai().length() > 10 || nsMoi.getSoDienThoai().length() < 10) {
//				System.out.println("SAI. Số điện thoại đúng 10 số");
//			}
//		}while(nsMoi.getSoDienThoai().length() > 10 || nsMoi.getSoDienThoai().length() < 10);
//		
//		nsMoi.setSoNgayLam(Float.parseFloat(inputValues("", sc, "Nhập số ngày làm: ")));
//		nsMoi.setLuongMotNgay(Float.parseFloat(inputValues("", sc, "Nhập tiền lương 1 ngày: ")));
//		return nsMoi;
//	}
	
	public void xuatThongTin() {
		System.out.println("-----");
		System.out.printf("Mã số: %d\nHọ tên: %s\nSố điện thoại: %s\nSố ngày làm: %.2f\nLương một ngày: %.2f\n", getMaSo(), getHoTen(),
				getSoDienThoai(), getSoNgayLam(), getLuongMotNgay());

	}

}
