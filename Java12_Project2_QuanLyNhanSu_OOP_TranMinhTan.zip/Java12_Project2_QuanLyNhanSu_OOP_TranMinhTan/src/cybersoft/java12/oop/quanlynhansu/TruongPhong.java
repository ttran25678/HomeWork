package cybersoft.java12.oop.quanlynhansu;

public class TruongPhong extends NhanSu{
	private int soNhanVien;

	public int getSoNhanVien() {
		return soNhanVien; 
	}

	public void setSoNhanVien(int soNhanVien) {
		this.soNhanVien = soNhanVien;
	}

	public TruongPhong() {
		super();
		this.soNhanVien = 0;
	}

	public TruongPhong(int maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
	}

	public TruongPhong(int maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay, int soNhanVien) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		this.soNhanVien = soNhanVien;
	}

	public int themSoLuongNV() {
		return ++soNhanVien;
	}
	
	@Override
	public void xuatThongTin() {
		// TODO Auto-generated method stub
		super.xuatThongTin();
		System.out.printf("Số nhân viên: %d\n", getSoNhanVien());
	}
	
	public TruongPhong themTruongPhong() {
		TruongPhong tpMoi = new TruongPhong();
		tpMoi.setHoTen(nhapString("", sc, "Nhập họ tên: "));
		do {
			tpMoi.setSoDienThoai(inputValues("", sc, "Nhập số điện thoại: "));
			if(tpMoi.getSoDienThoai().length() > 10 || tpMoi.getSoDienThoai().length() < 10 || !(tpMoi.getSoDienThoai().startsWith("0"))) {
				System.out.println("SAI. Số điện thoại đúng 10 số và bắt đầu bằng số 0 !");
			}
		}while(tpMoi.getSoDienThoai().length() > 10 || tpMoi.getSoDienThoai().length() < 10 || !(tpMoi.getSoDienThoai().startsWith("0")));
		tpMoi.setSoNgayLam(Float.parseFloat(inputValues("", sc, "Nhập số ngày làm: ")));
		tpMoi.setLuongMotNgay(Float.parseFloat(inputValues("", sc, "Nhập tiền lương 1 ngày: ")));
		return tpMoi;
	}
	
	@Override
	public float tinhLuong() {
		// TODO Auto-generated method stub
		float luong = super.tinhLuong();
		luong = luong + 100*this.getSoNhanVien();
		return luong;
	}
	

}
