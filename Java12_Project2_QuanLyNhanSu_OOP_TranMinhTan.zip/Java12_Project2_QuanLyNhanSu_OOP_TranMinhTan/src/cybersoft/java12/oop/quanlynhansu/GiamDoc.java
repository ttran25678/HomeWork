package cybersoft.java12.oop.quanlynhansu;

public class GiamDoc extends NhanSu{
	private float coPhan;

	public float getCoPhan() {
		return coPhan;
	}

	public void setCoPhan(float coPhan) {
		this.coPhan = coPhan;
	}

	public GiamDoc() {
		super();
	}
	
	public GiamDoc(int maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
	}

	public GiamDoc(int maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay, float coPhan) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		this.coPhan = coPhan;
	}

	@Override
	public void xuatThongTin() {
		// TODO Auto-generated method stub
		super.xuatThongTin();
		System.out.printf("Cổ phần: %.2f phần trăm\n", getCoPhan());
	}
	
	public GiamDoc themGiamDoc() {
		GiamDoc gdMoi = new GiamDoc();
		gdMoi.setHoTen(nhapString("", sc, "Nhập họ tên: "));
		do {
			gdMoi.setSoDienThoai(inputValues("", sc, "Nhập số điện thoại: "));
			if(gdMoi.getSoDienThoai().length() > 10 || gdMoi.getSoDienThoai().length() < 10 || !(gdMoi.getSoDienThoai().startsWith("0"))) {
				System.out.println("SAI. Số điện thoại đúng 10 số và bắt đầu bằng số 0 !");
			}
		}while(gdMoi.getSoDienThoai().length() > 10 || gdMoi.getSoDienThoai().length() < 10 || !(gdMoi.getSoDienThoai().startsWith("0")));
		gdMoi.setSoNgayLam(Float.parseFloat(inputValues("", sc, "Nhập số ngày làm: ")));
		gdMoi.setLuongMotNgay(Float.parseFloat(inputValues("", sc, "Nhập tiền lương 1 ngày: ")));
		gdMoi.setCoPhan(Float.parseFloat(inputValues("", sc, "Nhập số cổ phần: ")));
		return gdMoi;
	}
	
	@Override
	public float tinhLuong() {
		// TODO Auto-generated method stub
		return super.tinhLuong();
	}
		
	public void xuatThuNhapGiamDoc() {
		CongTy ct = new CongTy();
		NhanVien nv = new NhanVien();
		TruongPhong tp = new TruongPhong();
		
		double luong = super.tinhLuong();
		double coPhan = getCoPhan();
		double tongLuongCongTy = nv.tinhLuong() + tp.tinhLuong() + this.tinhLuong();
		luong = luong + coPhan * (ct.getDoanhThuThang() - tongLuongCongTy); // (Doanh thu tháng của công ty - tổng lương toàn công ty trong tháng.);
		System.out.printf("Thu nhập: %.2f", luong);
	}

}
