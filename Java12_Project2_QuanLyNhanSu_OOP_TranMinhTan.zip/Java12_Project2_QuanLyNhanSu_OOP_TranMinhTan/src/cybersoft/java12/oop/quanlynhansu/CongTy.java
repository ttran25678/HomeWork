package cybersoft.java12.oop.quanlynhansu;

import java.util.Scanner;

public class CongTy {

	private String ten;
	private String maSoThue;
	private double doanhThuThang;
	Scanner sc = new Scanner(System.in);

	public CongTy() {
		super();
	}

	public double getDoanhThuThang() {
		return doanhThuThang;
	}

	public void setDoanhThuThang(double doanhThuThang) {
		this.doanhThuThang = doanhThuThang;
	}

	public CongTy(String ten, String maSoThue, double doanhThuThang) {
		super();
		this.ten = ten;
		this.maSoThue = maSoThue;
		this.doanhThuThang = doanhThuThang;
	}

	public static boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?");
	}

	public void nhap() {

		System.out.printf("Nhập tên công ty: ");
		ten = sc.nextLine();
		System.out.printf("Nhập ma so thue: ");
		maSoThue = sc.nextLine();

		while (true) { // kiểm tra bắt buộc nhập số
			System.out.printf("Nhập doanh thu: ");
			String str = sc.nextLine();
			if (isNumeric(str)) { // input nhập vào là số
				doanhThuThang = Double.parseDouble(str);
				break;
			} else {
				System.out.println("SAI. Doanh thu kieu DOUBLE. Nhap lai !");
			}
		}

	}

	public void xuat() {
		System.out.printf("Tên công ty: %s\nMa so thue: %s\nDoanh thu: %f\n", ten, maSoThue, doanhThuThang);
	}

}
