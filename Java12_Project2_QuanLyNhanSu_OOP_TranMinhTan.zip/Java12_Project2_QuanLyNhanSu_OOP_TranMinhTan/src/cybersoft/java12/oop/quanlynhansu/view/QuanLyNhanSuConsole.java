package cybersoft.java12.oop.quanlynhansu.view;

import cybersoft.java12.oop.quanlynhansu.NhanSu;
import cybersoft.java12.oop.quanlynhansu.controller.QuanLyNhanSu;

public class QuanLyNhanSuConsole {
	QuanLyNhanSu quanLyNhanSu = new QuanLyNhanSu();
	
	public void inMenuThem() {
		
			System.out.println("------------------------");
			System.out.println("|1. Thêm Nhân viên     |");
			System.out.println("|2. Thêm Trưởng Phòng  |");
			System.out.println("|3. Thêm Giám Đốc      |");
			System.out.println("|4. Xóa nhân sự        |");
			System.out.println("------------------------");
			
	}

	public void inMenu() {
		System.out.println("-------------MENU--------------");
		System.out.println("1. Nhập thông tin công ty");
		System.out.println("2. Phân bổ Nhân viên vào Trưởng phòng");
		System.out.println("3. Thêm, xóa thông tin một nhân sự");
		System.out.println("4. Xuất ra thông tin toàn bộ người trong công ty");
		System.out.println("5. Tính và xuất tổng lương cho toàn công ty");
		System.out.println("6. Tìm Nhân viên thường có lương cao nhất");
		System.out.println("7. Tìm Trưởng Phòng có số lượng nhân viên dưới quyền nhiều nhất");
		System.out.println("8. Sắp xếp nhân viên toàn công ty theo thứ tự abc");
		System.out.println("9. Sắp xếp nhân viên toàn công ty theo thứ tự lương giảm dần");
		System.out.println("10. Tìm Giám Đốc có số lượng cổ phần nhiều nhất");
		System.out.println("11. Tính và Xuất tổng THU NHẬP của từng Giám Đốc");
		System.out.println("12. Thoát");
		System.out.println("-------------------------------");
		System.out.println();
	}
	
	public void inDanhSachNhanSu() {
		
		if(quanLyNhanSu.xuatSoLuongDSNhanSu() == 0) {
			System.out.println("---DANH SÁCH TRỐNG !\n");
		}else {
			quanLyNhanSu.xuatDSNhanSu();
			System.out.println();
		}	
	}
	
	public void themNhanSu(NhanSu nhanSu) {
		if(quanLyNhanSu.them(nhanSu)) {
			System.out.println("Thêm thành công !");
		}else {
			System.out.println("Thêm thất bại !");
		}
	}
	public void xoaNhanSu(int maSo) {
		if(quanLyNhanSu.xoa(maSo)) {
			System.out.println("Xóa thành công !");
		}else {
			System.out.println("Xóa thất bại !");
		}
	}
	
	public void themNVVaoTruongPhong() {
		if(quanLyNhanSu.themNVVaoTruongPhong()) {
			System.out.println("Thành công !");
		}else {
			System.out.println("Thất bại !");
		}
	}
	
	public void tongLuongCty() {
		System.out.printf("Tổng lương công ty = %.2f\n", quanLyNhanSu.tongLuong()); 
	}
	
	public void timNVLuongCaoNhat() {
		if(quanLyNhanSu.xuatSoLuongDSNhanSu() == 0) {
			System.out.println("---DANH SÁCH TRỐNG !\n");
		}else if(quanLyNhanSu.xuatSLNhanVien() == 0){
			System.out.println("---KHÔNG CÓ NHÂN VIÊN !\n");
		}else{
			System.out.println("Nhân Viên Thường có lương cao nhất là:");
			quanLyNhanSu.timNVLuongCaoNhat();
		}
	}
	
	
	public void timTPCoNhieuNVDuoiQuyen() {
		if(quanLyNhanSu.xuatSoLuongDSNhanSu() == 0) {
			System.out.println("---DANH SÁCH TRỐNG !\n");
		}else if(quanLyNhanSu.xuatSLTruongPhong() == 0){
			System.out.println("---KHÔNG CÓ TRƯỞNG PHÒNG !\n");
		}else{
			System.out.println("Trưởng Phòng có nhiều nhân viên dưới quyền nhiều nhất là:");
			quanLyNhanSu.timTPCoNhieuNV();
		}
	}

	
	public void timGDCoNhieuCoPhanNhat() {
		if(quanLyNhanSu.xuatSoLuongDSNhanSu() == 0) {
			System.out.println("---DANH SÁCH TRỐNG !\n");
		}else if(quanLyNhanSu.xuatSLGiamDoc() == 0){
			System.out.println("---KHÔNG CÓ GIÁM ĐỐC !\n");
		}else{
			System.out.println("Giám đốc có phần trăn cổ phần cao nhất là:");
			quanLyNhanSu.timGDCoNhieuCoPhanNhat();
		}
	}
	
	public void xuatThuNhapTungGiamDoc() {
		quanLyNhanSu.thuNhapTungGiamDoc();
	}
}
