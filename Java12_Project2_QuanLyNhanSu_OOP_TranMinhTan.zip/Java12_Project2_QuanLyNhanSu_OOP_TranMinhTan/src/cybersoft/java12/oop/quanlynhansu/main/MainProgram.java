package cybersoft.java12.oop.quanlynhansu.main;

import java.util.Scanner;

import cybersoft.java12.oop.quanlynhansu.CongTy;
import cybersoft.java12.oop.quanlynhansu.GiamDoc;
import cybersoft.java12.oop.quanlynhansu.NhanVien;
import cybersoft.java12.oop.quanlynhansu.TruongPhong;
import cybersoft.java12.oop.quanlynhansu.view.QuanLyNhanSuConsole;

public class MainProgram {

	
	public static boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?");
	}

	public static String nhapString(String str, Scanner sc, String mess) {

		while (true) {
			System.out.print(mess);
			str = sc.nextLine();

			if (isNumeric(str)) { // KT có phải là số hay k
				double thapPhan = Double.parseDouble(str); // ép kiểu đưa về kiểu int
				int soNguyen = (int) thapPhan;
				if (soNguyen == thapPhan) { // chỉ nhận kiểu int
					break;
				} else {
					System.out.println("SAI. Xin nhập lại !");
				}
			} else {
				System.out.println("SAI. Xin nhập lại !");
			}
		}

		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String str_choice = "";
		int choice;
		CongTy congTy;
		String str = "";
		

		QuanLyNhanSuConsole nhanSuConsole = new QuanLyNhanSuConsole();

		boolean flag = true;
		while (flag) {

			nhanSuConsole.inMenu();

			while (true) {
				System.out.print("Mời bạn chọn chức năng: ");
				str_choice = sc.nextLine();

				if (isNumeric(str_choice)) { // KT có phải là số hay k
					double temp = Double.parseDouble(str_choice); // ép kiểu đưa về kiểu int
					choice = (int) temp;
					if (choice == temp) { // chỉ chấp nhận ng dùng nhập 1.0, 2.0, 3.0
						if (choice >= 1 && choice <= 12)
							break;
						else
							System.out.println("SAI! Xin nhập lại ! [1:12]");
					} else {
						System.out.println("SAI! Nhập lựa chọn 1, 2 hoặc 3!");
					}
				} else {
					System.out.println("SAI! Nhập lựa chọn 1, 2 hoặc 3!");
				}
			}

			switch (choice) {
			case 1: {
				congTy = new CongTy();
				congTy.nhap();
				congTy.xuat();
				break;
			}
			case 2: {
				nhanSuConsole.themNVVaoTruongPhong();
				System.out.println();
				break;
			}
			case 3: {
				while (true) {
					nhanSuConsole.inMenuThem();
					int choice_sub;
					do {
						choice_sub = Integer.parseInt(nhapString(str, sc, "Vui lòng chọn: "));
						if (choice_sub < 1 || choice_sub > 4) {
							System.out.println("SAI.Vui lòng chọn 1,2 hoặc 3 !");
						}
					} while (choice_sub < 1 || choice_sub > 4);
					switch (choice_sub) {
					case 1: {
						NhanVien nv = new NhanVien();
						nhanSuConsole.themNhanSu(nv);
						break;
					}
					case 2: {
						TruongPhong tp = new TruongPhong();
						nhanSuConsole.themNhanSu(tp);
						break;
					}
					case 3: {
						GiamDoc gd = new GiamDoc();
						nhanSuConsole.themNhanSu(gd);
						break;
					}
					default:// case 4
						int maSoXoa = Integer.parseInt(nhapString("", sc, "Nhập mã số Nhân Sự cần xóa: "));
						nhanSuConsole.xoaNhanSu(maSoXoa);
						break;
					}
					
					break;
				}
				
				break;
			}
			case 4: {

				nhanSuConsole.inDanhSachNhanSu();

				break;
			}
			case 5: {
				nhanSuConsole.tongLuongCty();
				break;
			}
			case 6: {
				nhanSuConsole.timNVLuongCaoNhat();
				break;
			}
			case 7: {
				nhanSuConsole.timTPCoNhieuNVDuoiQuyen();
				break;
			}
			case 8: {
				
				break;
			}
			case 9: {

				break;
			}
			case 10: {
				nhanSuConsole.timGDCoNhieuCoPhanNhat();
				System.out.printf("");
				break;
			}
			case 11: {
				nhanSuConsole.xuatThuNhapTungGiamDoc();
				System.out.println();
				break;
			}
			default:
				System.out.println("========== TẠM BIỆT. HẸN GĂP LẠI ! =============");
				flag = false;
				break;
			}
		}

		sc.close();
	}

}
